//------------------------------------------------------------------------------
// File: TimestretchPlugin.cpp
//------------------------------------------------------------------------------

/*
 based on SoundTouch Audio Library v1.2.1
 Copyright (c) Olli Parviainen 2002-2003

 http://sky.prohosting.com/oparviai/soundtouch/README.html
*/

/*
* Modified for ReClock by OGO :)
*
*/

#include <stdio.h>

#include "TimestretchPlugin.h"
#include "FIFOSampleBuffer.h"

#include "SoundTouch.h"

using namespace soundtouch;

class PrivateData
{
	#define SAMPLE_LEN 0x10000

public:
	SoundTouch* m_st;
	soundtouch::SAMPLETYPE m_temp[SAMPLE_LEN];

	PrivateData(): m_st(0) 
	{}

	~PrivateData() 
	{
		if (m_st)
			delete[] m_st;
	}
};

#define GETPRIVATEDATA ((PrivateData*)m_privateData)

TimestretchPlugin::TimestretchPlugin()
{ 
	m_privateData = new PrivateData;

	SetParameters(1, 44100);
	SetPitch(1.0);
}

TimestretchPlugin::~TimestretchPlugin()
{
	assert(m_privateData);
	delete m_privateData;
}

void TimestretchPlugin::SetParameters(int channelCount, int sampleRate)
{
	assert(m_privateData);
	delete m_privateData;
	m_privateData = new PrivateData;

	m_channelCount = channelCount;
	m_latency = 0;

    bool usequickseek = false;
    bool useaafilter = false; //seems clearer without it
    int aafiltertaps = 56; //Def=32 doesnt matter coz its not used
    int seqms = 120; //reclock original is 82
    int seekwinms = 28; //reclock original is 28
    int overlapms = seekwinms; //reduces cutting sound if this is large
    int seqmslfe = 180; //larger value seems to preserve low frequencies better
    int seekwinmslfe = 42; //as percentage of seqms
    int overlapmslfe = seekwinmslfe; //reduces cutting sound if this is large

	if (channelCount)
	{
		if (m_channelCount == 2)
		{
			GETPRIVATEDATA->m_st = new SoundTouch[1];
			GETPRIVATEDATA->m_st[0].setChannels(2);
			GETPRIVATEDATA->m_st[0].setSampleRate(sampleRate);
			GETPRIVATEDATA->m_st[0].setSetting(SETTING_USE_QUICKSEEK, usequickseek);
			GETPRIVATEDATA->m_st[0].setSetting(SETTING_USE_AA_FILTER, useaafilter);
			//Added by Rodney
            GETPRIVATEDATA->m_st[0].setSetting(SETTING_AA_FILTER_LENGTH, aafiltertaps);
			GETPRIVATEDATA->m_st[0].setSetting(SETTING_SEQUENCE_MS, seqms); 
			GETPRIVATEDATA->m_st[0].setSetting(SETTING_SEEKWINDOW_MS, seekwinms);
			GETPRIVATEDATA->m_st[0].setSetting(SETTING_OVERLAP_MS, overlapms);
		}
		else if (m_channelCount % 2 == 0 && m_channelCount >= 6) //5.1, 7.1 only
        {
            GETPRIVATEDATA->m_st = new SoundTouch[m_channelCount/2 + 1];
			for(int i=0;i<(m_channelCount/2 + 1);i++)
			{

                /*if ((i == 1 || i == 2)) {
                    GETPRIVATEDATA->m_st[i].setChannels(1);
                } else {*/
                    GETPRIVATEDATA->m_st[i].setChannels(2);
                //}

                GETPRIVATEDATA->m_st[i].setSampleRate(sampleRate);
				GETPRIVATEDATA->m_st[i].setSetting(SETTING_USE_QUICKSEEK, usequickseek);
			    GETPRIVATEDATA->m_st[i].setSetting(SETTING_USE_AA_FILTER, useaafilter);
                GETPRIVATEDATA->m_st[i].setSetting(SETTING_AA_FILTER_LENGTH, aafiltertaps);
                switch(i){
                case '2': //for LFE
                    GETPRIVATEDATA->m_st[i].setSetting(SETTING_SEQUENCE_MS, seqmslfe);
                    GETPRIVATEDATA->m_st[i].setSetting(SETTING_SEEKWINDOW_MS, seekwinmslfe);
                    GETPRIVATEDATA->m_st[i].setSetting(SETTING_OVERLAP_MS, overlapmslfe);
                    break;
                default:
                    GETPRIVATEDATA->m_st[i].setSetting(SETTING_SEQUENCE_MS, seqms);
                    GETPRIVATEDATA->m_st[i].setSetting(SETTING_SEEKWINDOW_MS, seekwinms);
                    GETPRIVATEDATA->m_st[i].setSetting(SETTING_OVERLAP_MS, overlapms);
                    break;
                }

			}
        }
        else
		{
			GETPRIVATEDATA->m_st = new SoundTouch[m_channelCount];
			for(int i=0;i<m_channelCount;i++)
			{
				GETPRIVATEDATA->m_st[i].setChannels(1);
				GETPRIVATEDATA->m_st[i].setSampleRate(sampleRate);
				GETPRIVATEDATA->m_st[i].setSetting(SETTING_USE_QUICKSEEK, usequickseek);
				GETPRIVATEDATA->m_st[i].setSetting(SETTING_USE_AA_FILTER, useaafilter);
				//Added by Rodney
                GETPRIVATEDATA->m_st[i].setSetting(SETTING_AA_FILTER_LENGTH, aafiltertaps);
                GETPRIVATEDATA->m_st[i].setSetting(SETTING_SEQUENCE_MS, seqms);
				GETPRIVATEDATA->m_st[i].setSetting(SETTING_SEEKWINDOW_MS, seekwinms);
				GETPRIVATEDATA->m_st[i].setSetting(SETTING_OVERLAP_MS, overlapms);
			}
		}
	}
}

bool TimestretchPlugin::SetPitch(float pitch)
{
	m_pitch = pitch;

	if (m_channelCount && (pitch > 0.0f))
	{
		if (m_channelCount == 2)
		{
			GETPRIVATEDATA->m_st[0].setTempo(pitch);
		}
		else if (m_channelCount % 2 == 0 && m_channelCount >= 6)
        {
            for(int i=0;i<(m_channelCount/2 + 1);i++)
				GETPRIVATEDATA->m_st[i].setTempo(pitch);
        }
        else
		{
			for(int i=0;i<m_channelCount;i++)
				GETPRIVATEDATA->m_st[i].setTempo(pitch);
		}

		Flush();

		return true; // true for success
	}
	else
		return false;
}


void TimestretchPlugin::ProcessFlow(float *inBuffer, int inSamples, float *outBuffer, int *outSamples, int maxOutSamples)
{
	*outSamples = 0;

	if (m_channelCount && (m_pitch > 0.0f) && GETPRIVATEDATA && GETPRIVATEDATA->m_st)
	{
		if (m_channelCount == 2)
		{
			// input
			GETPRIVATEDATA->m_st[0].putSamples(inBuffer, inSamples/2);
			m_latency += ((float)inSamples) / m_pitch;

			// output
			float *osample = outBuffer;
			*outSamples = 0;

			while (maxOutSamples > 0)
			{
				int l_avail = GETPRIVATEDATA->m_st[0].receiveSamples(osample, maxOutSamples/2)*2;
				if (l_avail == 0)
					break;
				m_latency -= l_avail;
				(*outSamples) += l_avail;
				maxOutSamples -= l_avail;
				assert(maxOutSamples >= 0);
			}
		}
		else if (m_channelCount % 2 == 0 && m_channelCount >= 6)
        {
            *outSamples = 0;

            for (int c=0;c<(m_channelCount/2 + 1);c++) //process each soundtouch instance
			{
                int l_inSamples = inSamples / m_channelCount;

				// check if instance is C or LFE
                if ((c == 0 || c >= 3)) { //normal instance
                
                    // input
				    float* isample; //pointer to isample start
                        if (c == 0) {
                            isample = inBuffer; //pointer to isample start
                        } else {
                            isample = inBuffer+((c-1)*2); //pointer to isample start
                        }

				    while (l_inSamples > 0)
				    {
					    soundtouch::SAMPLETYPE* osample = GETPRIVATEDATA->m_temp;
    					
					    int i;

					    for(i=0; i<SAMPLE_LEN; i++)
					    {
						    *osample++ = *isample;
                            *osample++ = *(isample+1);
						    isample += m_channelCount;
						    if (--l_inSamples == 0)
							    break;
					    }


					    GETPRIVATEDATA->m_st[c].putSamples(GETPRIVATEDATA->m_temp, i);
					    m_latency += ((float)i*2) / m_pitch;
				    }		

				    // output
				    float* osample; //pointer to osample start
                        if (c == 0) {
                            osample = outBuffer; //pointer to osample start
                        } else {
                            osample = outBuffer+((c-1)*2); //pointer to osample start
                        }

				    int l_maxOutSamples = maxOutSamples / m_channelCount;
				    while (l_maxOutSamples > 0)
				    {
					    int l_sampleLen = (SAMPLE_LEN > l_maxOutSamples ? l_maxOutSamples : SAMPLE_LEN);
					    int l_avail = GETPRIVATEDATA->m_st[c].receiveSamples(GETPRIVATEDATA->m_temp, l_sampleLen)*2;
					    if (l_avail == 0)
						    break;
					    m_latency -= l_avail;
					    (*outSamples) += l_avail;
					    l_maxOutSamples -= l_avail;
					    assert(l_maxOutSamples >= 0);
					    for(int i=0; i<l_avail; i=i+2)
					    {
						    *osample = GETPRIVATEDATA->m_temp[i];
                            *(osample + 1) = GETPRIVATEDATA->m_temp[i+1];
						    osample += m_channelCount;
					    }
				    }

                } else { //C or LFE instance
                    /*
				    // input
				    float* isample = inBuffer+(c+1);

				    while (l_inSamples > 0)
				    {
					    soundtouch::SAMPLETYPE* osample = GETPRIVATEDATA->m_temp;
    					
					    int i;

					    for(i=0; i<SAMPLE_LEN; i++)
					    {
						    *osample++ = *isample;
						    isample += m_channelCount;
						    if (--l_inSamples == 0)
							    break;
					    }

					    GETPRIVATEDATA->m_st[c].putSamples(GETPRIVATEDATA->m_temp, i);
					    m_latency += ((float)i) / m_pitch;
				    }		

				    // output
				    float *osample = outBuffer+(c+1);

				    int l_maxOutSamples = maxOutSamples / m_channelCount;
				    while (l_maxOutSamples > 0)
				    {
					    int l_sampleLen = (SAMPLE_LEN > l_maxOutSamples ? l_maxOutSamples : SAMPLE_LEN);
					    int l_avail = GETPRIVATEDATA->m_st[c].receiveSamples(GETPRIVATEDATA->m_temp, l_sampleLen);
					    if (l_avail == 0)
						    break;
					    m_latency -= l_avail;
					    (*outSamples) += l_avail;
					    l_maxOutSamples -= l_avail;
					    assert(l_maxOutSamples >= 0);
					    for(int i=0; i<l_avail; i++)
					    {
						    *osample = GETPRIVATEDATA->m_temp[i];
						    osample += m_channelCount;
					    }
				    }*/
                /******************************************/
                    // input
				    float* isample = inBuffer+(c+1);
				    while (l_inSamples > 0)
				    {
					    soundtouch::SAMPLETYPE* osample = GETPRIVATEDATA->m_temp;
    					
					    int i;

					    for(i=0; i<SAMPLE_LEN; i++)
					    {
						    *osample++ = *isample; //C or LFE channel itself
                            if(c == 1) //c=1 so C
                                *osample++ = *(isample-c)*0.25 + *(isample-(c+1))*0.25 + *(isample+1)*0.25 + *(isample)*0.25; //L+R + C+LFE
                            else //c=2 so LFE
                                *osample++ = *(isample-c)*0.25 + *(isample-(c+1))*0.25 + *(isample-1)*0.25 + *(isample)*0.25; //L+R + C+LFE
						    isample += m_channelCount;
						    if (--l_inSamples == 0)
							    break;
					    }

					    GETPRIVATEDATA->m_st[c].putSamples(GETPRIVATEDATA->m_temp, i);
					    m_latency += ((float)i) / m_pitch; //latency is only i!
				    }		

				    // output
                    float *osample = outBuffer+(c+1);

				    int l_maxOutSamples = maxOutSamples / m_channelCount;
				    while (l_maxOutSamples > 0)
				    {
					    int l_sampleLen = (SAMPLE_LEN > l_maxOutSamples ? l_maxOutSamples : SAMPLE_LEN);
					    int l_avail = GETPRIVATEDATA->m_st[c].receiveSamples(GETPRIVATEDATA->m_temp, l_sampleLen)*2;
					    if (l_avail == 0)
						    break;
					    m_latency -= l_avail / 2; //latency is half i
					    (*outSamples) += l_avail / 2; //number of outsamples is half i
					    l_maxOutSamples -= l_avail;
					    assert(l_maxOutSamples >= 0);
					    for(int i=0; i<l_avail; i=i+2)
					    {
						    *osample = GETPRIVATEDATA->m_temp[i]*2.0;
						    osample += m_channelCount;
					    }
				    }
                /******************************************/
                }
			}
        }
        else
		{
			*outSamples = 0;

			for (int c=0;c<m_channelCount;c++)
			{
				// input
				int l_inSamples = inSamples / m_channelCount;
				float* isample = inBuffer+c;

				while (l_inSamples > 0)
				{
					soundtouch::SAMPLETYPE* osample = GETPRIVATEDATA->m_temp;
					
					int i;

					for(i=0; i<SAMPLE_LEN; i++)
					{
						*osample++ = *isample;
						isample += m_channelCount;
						if (--l_inSamples == 0)
							break;
					}

					GETPRIVATEDATA->m_st[c].putSamples(GETPRIVATEDATA->m_temp, i);
					m_latency += ((float)i) / m_pitch;
				}		

				// output
				float *osample = outBuffer+c;

				int l_maxOutSamples = maxOutSamples / m_channelCount;
				while (l_maxOutSamples > 0)
				{
					int l_sampleLen = (SAMPLE_LEN > l_maxOutSamples ? l_maxOutSamples : SAMPLE_LEN);
					int l_avail = GETPRIVATEDATA->m_st[c].receiveSamples(GETPRIVATEDATA->m_temp, l_sampleLen);
					if (l_avail == 0)
						break;
					m_latency -= l_avail;
					(*outSamples) += l_avail;
					l_maxOutSamples -= l_avail;
					assert(l_maxOutSamples >= 0);
					for(int i=0; i<l_avail; i++)
					{
						*osample = GETPRIVATEDATA->m_temp[i];
						osample += m_channelCount;
					}
				}
			}
		}
	}
}

void TimestretchPlugin::Flush()
{
	if (m_channelCount && GETPRIVATEDATA && GETPRIVATEDATA->m_st)
	{
		if (m_channelCount == 2)
		{
			GETPRIVATEDATA->m_st[0].flush();
			while (GETPRIVATEDATA->m_st[0].receiveSamples(SAMPLE_LEN))
				;
		}
		else if (m_channelCount % 2 == 0 && m_channelCount >= 6)
        {
            for(int i=0;i<(m_channelCount/2 + 1);i++)
			{
				GETPRIVATEDATA->m_st[i].flush();
				while (GETPRIVATEDATA->m_st[i].receiveSamples(SAMPLE_LEN))
					;
			}
        }
        else
		{
			for(int i=0;i<m_channelCount;i++)
			{
				GETPRIVATEDATA->m_st[i].flush();
				while (GETPRIVATEDATA->m_st[i].receiveSamples(SAMPLE_LEN))
					;
			}
		}
	}

	m_latency = 0;
}
