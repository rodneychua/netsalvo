//------------------------------------------------------------------------------
// File: TimestretchPlugin.h
//------------------------------------------------------------------------------

#ifndef __TIMESTRETCH_PLUGIN__
#define __TIMESTRETCH_PLUGIN__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifdef BUILD_TIMESTRETCH
	#define _DLLCLASS __declspec( dllexport )
#else
	#define _DLLCLASS __declspec( dllimport )
#endif

class _DLLCLASS TimestretchPlugin
{
	int			m_channelCount;
	float		m_pitch;
	float		m_latency;

	void*		m_privateData;

public:
	TimestretchPlugin();
	~TimestretchPlugin();

	void SetParameters(int channelCount, int sampleRate);
	bool SetPitch(float pitch);
	
	float GetPitch() { return m_pitch; }
	unsigned int GetLatency() { if (m_latency > 0) return (unsigned int)(m_latency + 0.5); else return 0; } // expressed in samples

	void ProcessFlow(float *inBuffer, int inSamples, float *outBuffer, int *outSamples, int maxOutSamples);
	
	void Flush();
};

#endif // __TIMESTRETCH_PLUGIN__
